import avecTemplateHtml from '../utils/avecTemplateHtml.js'

export default avecTemplateHtml({
    template: 'components/splash.html'
})