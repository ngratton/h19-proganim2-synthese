import avecTemplateHtml from '../utils/avecTemplateHtml.js'

export default avecTemplateHtml({
    template: 'components/victoire.html',
    data() {
        return {
        }
    },
})