import router from './router.js'

new Vue({
    el: '#app',
    router,
    data: {
    },
})
